Prequisites:

Download and instalation:
------------------------------------

1. NodeJS should installed and setup.
2. Protractor should be installed and setup. (npm install -g protractor@5.4.2)
3. Chrome Browser should be installed.
4. JDK installed.
5  Webdrvier manager update
6. Start Webdriver manager from command line and should be running (webdriver-manager start)
7. Visual studio code should be installed



Steps to execute the autoamted test suite:

  *  Extract INVIA_TestTask.zip at your desktop
  *  Open Visual Studio Code
  *  Once VSC is opened, then navigate to File menu > Open Folder > select INVIA_TestTask from dektop (Project is imported in VSC)
  *  Now go to view menu and click on sub menu "Terminal"
  *  Run the following command at terminal.
     -   protractor config.js

  Project will start to execute and wait till the execution get completed.



 

	